import pandas as pd
import numpy as np
from gensim import utils

from keras.models import Sequential, Model
from keras.layers import Dense, Activation, Flatten, Input, Dropout, MaxPooling1D, Convolution1D
from keras.layers import LSTM, GRU, Lambda, merge
from keras.layers import Embedding, TimeDistributed
import numpy as np
from unidecode import unidecode
import re
from keras import backend as K

import sys
import os


def max_1d(X):
    return K.max(X, axis=1)
 
total = len(sys.argv)
cmdargs = str(sys.argv)

print ("Script name: %s" % str(sys.argv[0]))
checkpoint = None
if len(sys.argv) == 2:
    if os.path.exists(str(sys.argv[1])):
        print ("Checkpoint : %s" % str(sys.argv[1]))
        checkpoint = str(sys.argv[1])

csv = 'cocacola_url_alexa_sentiment_text_title.csv'
data = pd.read_csv(csv)

txt = ''
docs = []
sentences = []
sentiments = []

for cont, sentiment in zip(data.text, data.sentiment):
    cont = unidecode(utils.to_unicode(cont))    
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', cont)
    sentences = [sent.strip().lower() for sent in sentences]
    if len(sentences) > 30:
        continue
    sentences = [' '.join(word for word in s.split() if len(word) < 30) for s in sentences]
    docs.append(sentences)
#     txt += (' '.join(word for word in s.split() if len(word)<30).strip().lower())
    sentiments.append(sentiment)

for doc in docs:
    for s in doc:
        txt +=s

chars = set(txt)

print('total chars:', len(chars))
char_indices = dict((c, i+1) for i, c in enumerate(chars))
indices_char = dict((i+1, c) for i, c in enumerate(chars))

print('Sample doc{}'.format(docs[122]))

maxlen = 512
max_sentences = 20

X = np.zeros((len(docs), max_sentences, maxlen))
y = np.zeros((len(docs), 3))

for i, doc in enumerate(docs):
    for j, sentence in enumerate(doc):
        if j < max_sentences:
            for t, char in enumerate(sentence[-maxlen:]):

                X[i, j, t] = char_indices[char]
    
    if sentiments[i] == 'Positive':
        y[i, 0] = 1
    elif sentiments[i] == 'Negative':
        y[i, 1] = 1
    else:
        y[i, 2] = 1

print('Sample X:{}'.format(X[122, 2]))
print('y:{}'.format(y.sum(axis=0)))
max_features = len(chars)+1
char_embedding = 30

filter_length = [3, 3, 2]
nb_filter = [128, 128, 256]
pool_length = 2

sequence = Input(shape=(max_sentences, maxlen), dtype='int32')

sent_encode = Sequential()
sent_encode.add(Embedding(max_features, char_embedding, input_length=maxlen))
sent_encode.add(Dropout(0.1))

for l in range(len(nb_filter)):
    sent_encode.add(Convolution1D(nb_filter=nb_filter[l],
                                  filter_length=filter_length[l],
                                  border_mode='valid',
                                  activation='relu',
                                  subsample_length=1))
    sent_encode.add(Dropout(0.2))
    if l < 2:
        sent_encode.add(MaxPooling1D(pool_length=pool_length))

sent_encode.add(Lambda(max_1d, output_shape=(nb_filter[-1],)))
sent_encode.add(Dense(256, activation='relu'))

# sent_encode.add(LSTM(256, return_sequences=False, dropout_W=0.2, dropout_U=0.2, consume_less='cpu'))
# sent_encode.add(Flatten())
# sent_encode.add(Dense(300, activation='relu'))
# sent_encode.add(Dropout(0.5))
# sent_encode.add(Dense(200, activation='relu'))

encoded = TimeDistributed(sent_encode)(sequence)

forwards = LSTM(64, return_sequences=False, dropout_W=0.2, dropout_U=0.2, consume_less='gpu')(encoded)
backwards = LSTM(64, return_sequences=False, dropout_W=0.2, dropout_U=0.2, consume_less='gpu', go_backwards=True)(encoded)

merged = merge([forwards, backwards], mode='concat', concat_axis=-1)

output = Dropout(0.2)(merged)
output = Dense(3, activation='softmax')(output)

model = Model(input=sequence, output=output)
if checkpoint:
    model.load_weights(checkpoint)
    
model.compile(loss='categorical_crossentropy', optimizer='adam', metrics=['accuracy'])

model.fit(X, y, batch_size=16, nb_epoch=60, shuffle=True)

model.save_weights('checkpoints/doc-cnn.h5', overwrite=True)
