import pandas as pd

from keras.models import Model
from keras.layers import Dense, Activation, Flatten, Input, Dropout, MaxPooling1D, Convolution1D
from keras.layers import LSTM, GRU, Lambda, merge
from keras.layers import Embedding, TimeDistributed
import numpy as np

import re
from keras import backend as K
import keras.callbacks
import sys
import os


def max_1d(X):
    return K.max(X, axis=1)


def striphtml(data):
    p = re.compile(r'<.*?>')
    return p.sub('', data)

total = len(sys.argv)
cmdargs = str(sys.argv)

print ("Script name: %s" % str(sys.argv[0]))
checkpoint = None
if len(sys.argv) == 2:
    if os.path.exists(str(sys.argv[1])):
        print ("Checkpoint : %s" % str(sys.argv[1]))
        checkpoint = str(sys.argv[1])


data = pd.read_csv("labeledTrainData.tsv", header=0, delimiter="\t", quoting=3)
txt = ''
docs = []
sentences = []
sentiments = []

for cont, sentiment in zip(data.review, data.sentiment):
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', striphtml(cont))
    sentences = [sent.lower() for sent in sentences]
    docs.append(sentences)
    sentiments.append(sentiment)

num_sent = []
for doc in docs:
    num_sent.append(len(doc))
    for s in doc:
        txt += s

chars = set(txt)

print('total chars:', len(chars))
char_indices = dict((c, i + 1) for i, c in enumerate(chars))
indices_char = dict((i + 1, c) for i, c in enumerate(chars))

print('Sample doc{}'.format(docs[1200]))

maxlen = 512
max_sentences = 20

X = np.zeros((len(docs), max_sentences, maxlen))
y = np.array(sentiments)

for i, doc in enumerate(docs):
    for j, sentence in enumerate(doc):
        if j < max_sentences:
            for t, char in enumerate(sentence[-maxlen:]):
                X[i, j, t] = char_indices[char]
    # y[i, sentiments[i]] = 1


print('Sample X:{}'.format(X[1200, 2]))
print('y:{}'.format(y[1200]))

ids = np.arange(len(X))
np.random.shuffle(ids)

# shuffle
X = X[ids]
y = y[ids]

X_train = X[:20000]
X_test = X[20000:]

y_train = y[:20000]
y_test = y[20000:]


def char_block(in_layer, nb_filter=[64, 100], filter_length=[3, 3], pool_length=2):
    block = in_layer
    for i in range(len(nb_filter)):

        block = Convolution1D(nb_filter=nb_filter[i],
                              filter_length=filter_length[i],
                              border_mode='valid',
                              activation='relu',
                              subsample_length=1)(block)
        block = Dropout(0.25)(block)
        if i == len(nb_filter)-1:
            continue
        block = MaxPooling1D(pool_length=pool_length)(block)

    # block = Convolution1D(nb_filter=64,
    #                       filter_length=2,
    #                       border_mode='valid',
    #                       activation='relu',
    #                       subsample_length=1)(block)

    block = Lambda(max_1d, output_shape=(nb_filter[-1],))(block)
    return block

max_features = len(chars) + 1
char_embedding = 30
filter_length = [3, 2, 2]
nb_filter = [64, 64, 64]
pool_length = 2
layers = [128, 128]

sequence = Input(shape=(max_sentences, maxlen), dtype='int32')

in_sentence = Input(shape=(maxlen,), dtype='int32')
embedded = Embedding(max_features, char_embedding, input_length=maxlen)(in_sentence)
embedded = Dropout(0.15)(embedded)

block1 = char_block(embedded, [60, 80], filter_length=[3, 3])
block2 = char_block(embedded, [80, 100], filter_length=[5, 2])
block3 = char_block(embedded, [100, 128], filter_length=[7, 2])

sent_encode = merge([block1, block2, block3], mode='concat', concat_axis=-1)
sent_encode = Dropout(0.3)(sent_encode)
sent_encode = Dense(256, activation='relu')(sent_encode)
sent_encode = Dropout(0.4)(sent_encode)

encoder = Model(input=in_sentence, output=sent_encode)
encoded = TimeDistributed(encoder)(sequence)

forwards = LSTM(100, return_sequences=False, dropout_W=0.2, dropout_U=0.2, consume_less='gpu')(encoded)
backwards = LSTM(100, return_sequences=False, dropout_W=0.2, dropout_U=0.2, consume_less='gpu', go_backwards=True)(encoded)

merged = merge([forwards, backwards], mode='concat', concat_axis=-1)

output = Dropout(0.35)(merged)
output = Dense(1, activation='sigmoid')(output)

model = Model(input=sequence, output=output)


if checkpoint:
    model.load_weights(checkpoint)

file_name = os.path.basename(sys.argv[0]).split('.')[0]

check_cb = keras.callbacks.ModelCheckpoint('checkpoints/'+file_name+'.{epoch:02d}-{val_loss:.2f}.hdf5', monitor='val_loss',
                                           verbose=0, save_best_only=True, mode='min')

model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

model.fit(X_train, y_train, validation_data=(X_test, y_test), batch_size=12,
          nb_epoch=60, shuffle=True, callbacks=[check_cb])

# loss = model.evaluate(X_test, y_test, batch_size=16)
# print loss

# model.save_weights('checkpoints/doc-cnn3.h5', overwrite=True)
